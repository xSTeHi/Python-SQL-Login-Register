from modules import funzioni, menu

while(True):
	menu.menu()
	menu.clear()